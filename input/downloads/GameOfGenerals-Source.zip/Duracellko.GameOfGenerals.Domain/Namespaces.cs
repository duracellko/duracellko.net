﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    internal static class Namespaces
    {
        public const string DataNamespace = "http://duracellko.net/GameOfGenerals/Data";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    [DataContract(Namespace = Namespaces.DataNamespace)]
    public enum PieceColor
    {
        [EnumMember]
        White = 0,

        [EnumMember]
        Black = -1
    }
}

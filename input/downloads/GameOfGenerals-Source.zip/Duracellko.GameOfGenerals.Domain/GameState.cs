﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    public enum GameState
    {
        Setup,
        WhiteMoves,
        BlackMoves,
        WhiteWon,
        BlackWon
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    [DataContract(Namespace = Namespaces.DataNamespace)]
    public enum MoveDirection
    {
        [EnumMember]
        Forward,

        [EnumMember]
        Backward,
        
        [EnumMember]
        Right,
        
        [EnumMember]
        Left
    }
}

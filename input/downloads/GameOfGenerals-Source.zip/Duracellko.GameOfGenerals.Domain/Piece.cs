﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    public class Piece
    {

        #region Constructor

        public Piece(PieceColor color, PieceType type)
        {
            this.Color = color;
            this.Type = type;
        }

        #endregion

        #region Properties

        public PieceColor Color { get; private set; }

        public PieceType Type { get; private set; }

        #endregion

        #region Public methods

        public ChallengeResult Challenge(Piece enemy)
        {
            if (enemy == null)
            {
                throw new ArgumentNullException("enemy");
            }

            if (this.Type == enemy.Type)
            {
                return this.Type == PieceType.Flag ? ChallengeResult.Win : ChallengeResult.BothAreEliminated;
            }

            if (this.Type == PieceType.Spy)
            {
                return enemy.Type == PieceType.Private ? ChallengeResult.Lose : ChallengeResult.Win;
            }
            else if (enemy.Type == PieceType.Spy)
            {
                return this.Type == PieceType.Private ? ChallengeResult.Win : ChallengeResult.Lose;
            }
            else
            {
                return this.Type > enemy.Type ? ChallengeResult.Win : ChallengeResult.Lose;
            }
        }

        #endregion
    }
}

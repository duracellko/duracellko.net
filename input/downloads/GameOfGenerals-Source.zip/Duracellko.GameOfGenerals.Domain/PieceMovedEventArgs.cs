﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    public class PieceMovedEventArgs : EventArgs
    {

        public PieceMovedEventArgs(int x, int y, MoveDirection direction)
        {
            this.X = x;
            this.Y = y;
            this.Direction = direction;
        }

        public int X { get; private set; }

        public int Y { get; private set; }

        public MoveDirection Direction { get; private set; }

    }
}

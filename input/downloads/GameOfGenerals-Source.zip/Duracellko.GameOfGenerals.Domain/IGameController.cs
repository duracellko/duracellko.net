﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    public interface IGameController
    {
        #region Properties

        PieceColor MyColor { get; }

        PieceColor OpponentColor { get; }

        GameState State { get; }

        int Columns { get; }

        int Rows { get; }

        Piece this[int x, int y] { get; }

        IEnumerable<Piece> AvailablePieces { get; }

        IEnumerable<Piece> EliminatedPieces { get; }

        #endregion

        #region Public methods

        bool IsPieceMyColor(int x, int y);

        void SetupPiece(Piece piece, int x, int y);

        BoardCoordinates GetMoveCoordinates(int x, int y, MoveDirection direction);

        BoardCoordinates GetMoveCoordinates(int x, int y, MoveDirection direction, bool forPlayerOnMove);

        bool CanMove(int x, int y, MoveDirection direction);

        bool Move(int x, int y, MoveDirection direction);

        #endregion

        #region Events

        event EventHandler GameChanged;

        event EventHandler<PieceMovedEventArgs> PieceMoved;

        #endregion
    }
}

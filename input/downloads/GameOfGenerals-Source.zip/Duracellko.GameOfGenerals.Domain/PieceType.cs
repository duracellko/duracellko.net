﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    [DataContract(Namespace = Namespaces.DataNamespace)]
    public enum PieceType
    {
        [EnumMember]
        Flag = 0,
        
        [EnumMember]
        Spy = 1,
        
        [EnumMember]
        Private = 2,
        
        [EnumMember]
        Sergeant = 3,
        
        [EnumMember]
        SecondLieutenant = 4,
        
        [EnumMember]
        FirstLieutenant = 5,
        
        [EnumMember]
        Captain = 6,
        
        [EnumMember]
        Major = 7,
        
        [EnumMember]
        LtColonel = 8,
        
        [EnumMember]
        Colonel = 9,
        
        [EnumMember]
        OneStarGeneral = 10,
        
        [EnumMember]
        TwoStarsGeneral = 11,
        
        [EnumMember]
        ThreeStarsGeneral = 12,
        
        [EnumMember]
        FourStarsGeneral = 13,
        
        [EnumMember]
        FiveStarsGeneral = 14
    }
}

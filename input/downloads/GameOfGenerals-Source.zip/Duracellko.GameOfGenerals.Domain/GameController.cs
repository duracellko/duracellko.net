﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    public class GameController : IGameController
    {
        #region Fields

        private readonly GameBoard gameBoard = new GameBoard();

        #endregion

        #region Constructor

        public GameController(PieceColor color)
        {
            this.MyColor = color;
            this.State = GameState.Setup;
        }

        #endregion

        #region Properties

        public PieceColor MyColor { get; private set; }

        public PieceColor OpponentColor
        {
            get { return GetOppositeColor(this.MyColor); }
        }

        public GameState State { get; private set; }

        public int Columns
        {
            get { return this.gameBoard.Columns; }
        }

        public int Rows
        {
            get { return this.gameBoard.Rows; }
        }

        public Piece this[int x, int y]
        {
            get { return this.gameBoard[x, y]; }
        }

        public IEnumerable<Piece> AvailablePieces
        {
            get { return this.gameBoard.AvailablePieces; }
        }

        public IEnumerable<Piece> EliminatedPieces
        {
            get { return this.gameBoard.EliminatedPieces; }
        }

        #endregion

        #region Public methods

        public static PieceColor GetOppositeColor(PieceColor color)
        {
            return color ^ PieceColor.Black;
        }

        public bool IsPieceMyColor(int x, int y)
        {
            return this.gameBoard.IsPieceColor(x, y, this.MyColor);
        }

        public void SetupPiece(Piece piece, int x, int y)
        {
            if (piece == null)
            {
                throw new ArgumentNullException("piece");
            }

            if (this.State != GameState.Setup)
            {
                throw new InvalidOperationException();
            }

            if ((piece.Color == PieceColor.White && y >= this.gameBoard.Rows / 2) ||
                (piece.Color == PieceColor.Black && y < this.gameBoard.Rows / 2))
            {
                throw new InvalidOperationException(Properties.Resources.Error_SetPieceOnOpponentSide);
            }

            this.gameBoard[x, y] = piece;
            this.OnGameChanged(EventArgs.Empty);

            if (this.gameBoard.AreAllPiecesInGame)
            {
                this.State = GameState.WhiteMoves;
                this.OnGameChanged(EventArgs.Empty);
            }
        }

        public BoardCoordinates GetMoveCoordinates(int x, int y, MoveDirection direction)
        {
            return this.GetMoveCoordinates(x, y, direction, false);
        }

        public BoardCoordinates GetMoveCoordinates(int x, int y, MoveDirection direction, bool forPlayerOnMove)
        {
            PieceColor color;
            if (forPlayerOnMove)
            {
                switch (this.State)
                {
                    case GameState.WhiteMoves:
                        color = PieceColor.White;
                        break;
                    case GameState.BlackMoves:
                        color = PieceColor.Black;
                        break;
                    default:
                        color = this.MyColor;
                        break;
                }
            }
            else
            {
                color = this.MyColor;
            }

            return this.gameBoard.GetMoveCoordinates(x, y, direction, color);
        }

        public bool CanMove(int x, int y, MoveDirection direction)
        {
            return this.gameBoard.CanMove(x, y, direction, this.MyColor);
        }

        public bool Move(int x, int y, MoveDirection direction)
        {
            if (this.State != GameState.WhiteMoves && this.State != GameState.BlackMoves)
            {
                throw new InvalidOperationException();
            }

            var color = this.State == GameState.WhiteMoves ? PieceColor.White : PieceColor.Black;
            var result = this.gameBoard.Move(x, y, direction, color);
            this.OnPieceMoved(new PieceMovedEventArgs(x, y, direction));

            if (result)
            {
                this.State = this.State == GameState.WhiteMoves ? GameState.WhiteWon : GameState.BlackWon;
            }
            else
            {
                this.State = this.State == GameState.WhiteMoves ? GameState.BlackMoves : GameState.WhiteMoves;
            }

            this.OnGameChanged(EventArgs.Empty);
            return result;
        }

        #endregion

        #region Events

        public event EventHandler GameChanged;

        protected virtual void OnGameChanged(EventArgs e)
        {
            if (this.GameChanged != null)
            {
                this.GameChanged(this, e);
            }
        }

        public event EventHandler<PieceMovedEventArgs> PieceMoved;

        protected virtual void OnPieceMoved(PieceMovedEventArgs e)
        {
            if (this.PieceMoved != null)
            {
                this.PieceMoved(this, e);
            }
        }

        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Domain
{
    public class GameBoard
    {
        #region Fields

        private readonly Piece[,] board = new Piece[9, 8];
        private readonly List<Piece> availablePieces = new List<Piece>();
        private readonly List<Piece> eliminatedPieces = new List<Piece>();

        #endregion

        #region Constructor

        public GameBoard()
        {
            this.CreatePieces();
        }

        #endregion

        #region Properties

        public int Columns
        {
            get { return this.board.GetLength(0); }
        }

        public int Rows
        {
            get { return this.board.GetLength(1); }
        }

        public Piece this[int x, int y]
        {
            get
            {
                this.ValidateCoordinates(x, y, true);
                return this.board[x, y];
            }

            set
            {
                this.ValidateCoordinates(x, y, true);
                if (value != this.board[x, y])
                {
                    if (this.board[x, y] != null)
                    {
                        throw new InvalidOperationException(Properties.Resources.Error_CoordinatesOccupied);
                    }

                    if (!this.availablePieces.Remove(value))
                    {
                        throw new ArgumentException(Properties.Resources.Error_PieceIsNotAvailable, "value");
                    }

                    this.SetPiece(x, y, value);
                }
            }
        }

        public IEnumerable<Piece> AvailablePieces
        {
            get { return this.availablePieces; }
        }

        public IEnumerable<Piece> EliminatedPieces
        {
            get { return this.eliminatedPieces; }
        }

        public bool AreAllPiecesInGame
        {
            get { return this.availablePieces.Count == 0; }
        }

        #endregion

        #region Public methods

        public bool IsPieceColor(int x, int y, PieceColor color)
        {
            this.ValidateCoordinates(x, y, true);

            var piece = this[x, y];
            return piece != null && piece.Color == color;
        }

        public BoardCoordinates GetMoveCoordinates(int x, int y, MoveDirection direction, PieceColor color)
        {
            this.ValidateCoordinates(x, y, true);

            int newX = x;
            int newY = y;
            int step = color == PieceColor.Black ? -1 : 1;

            switch (direction)
            {
                case MoveDirection.Forward:
                    newY += step;
                    break;
                case MoveDirection.Backward:
                    newY -= step;
                    break;
                case MoveDirection.Right:
                    newX += step;
                    break;
                case MoveDirection.Left:
                    newX -= step;
                    break;
            }

            return new BoardCoordinates(newX, newY);
        }

        public bool CanMove(int x, int y, MoveDirection direction, PieceColor color)
        {
            this.ValidateCoordinates(x, y, true);

            if (!this.IsPieceColor(x, y, color))
            {
                return false;
            }

            var newCoordinates = this.GetMoveCoordinates(x, y, direction, color);

            if (!this.ValidateCoordinates(newCoordinates.X, newCoordinates.Y, false))
            {
                return false;
            }

            if (this.IsPieceColor(newCoordinates.X, newCoordinates.Y, color))
            {
                return false;
            }

            return true;
        }

        public bool Move(int x, int y, MoveDirection direction, PieceColor color)
        {
            if (!this.CanMove(x, y, direction, color))
            {
                throw new InvalidOperationException(Properties.Resources.Error_CannotMove);
            }

            var newCoordinates = this.GetMoveCoordinates(x, y, direction, color);
            var piece = this[x, y];
            var enemy = this[newCoordinates.X, newCoordinates.Y];
            this.SetPiece(x, y, null);

            if (enemy != null)
            {
                var challengeResult = piece.Challenge(enemy);
                switch (challengeResult)
                {
                    case ChallengeResult.Win:
                        this.SetPiece(newCoordinates.X, newCoordinates.Y, piece);
                        this.eliminatedPieces.Add(enemy);
                        if (enemy.Type == PieceType.Flag)
                        {
                            return true;
                        }

                        break;
                    case ChallengeResult.Lose:
                        this.eliminatedPieces.Add(piece);
                        break;
                    case ChallengeResult.BothAreEliminated:
                        this.SetPiece(newCoordinates.X, newCoordinates.Y, null);
                        this.eliminatedPieces.Add(enemy);
                        this.eliminatedPieces.Add(piece);
                        break;
                }
            }
            else
            {
                this.SetPiece(newCoordinates.X, newCoordinates.Y, piece);

                if (piece.Type == PieceType.Flag)
                {
                    var endRow = color == PieceColor.White ? this.Rows - 1 : 0;
                    if (newCoordinates.Y == endRow)
                    {
                        var surroundingEnemies = this.GetSurroundingPieces(newCoordinates.X, newCoordinates.Y).Where(p => p.Color != color);
                        return !surroundingEnemies.Any();
                    }
                }
            }

            return false;
        }

        #endregion

        #region Private methods

        private bool ValidateCoordinates(int x, int y, bool throwException)
        {
            if (x < 0 || x >= this.Columns)
            {
                if (throwException)
                {
                    throw new ArgumentOutOfRangeException("x");
                }
                else
                {
                    return false;
                }
            }

            if (y < 0 || y >= this.Rows)
            {
                if (throwException)
                {
                    throw new ArgumentOutOfRangeException("y");
                }
                else
                {
                    return false;
                }
            }

            return true;
        }

        private void SetPiece(int x, int y, Piece piece)
        {
            this.board[x, y] = piece;
        }

        private IEnumerable<Piece> GetSurroundingPieces(int x, int y)
        {
            int newX = x + 1;
            int newY = y;
            if (this.ValidateCoordinates(newX, newY, false))
            {
                var piece = this[newX, newY];
                if (piece != null)
                {
                    yield return piece;
                }
            }

            newX = x - 1;
            newY = y;
            if (this.ValidateCoordinates(newX, newY, false))
            {
                var piece = this[newX, newY];
                if (piece != null)
                {
                    yield return piece;
                }
            }

            newX = x;
            newY = y + 1;
            if (this.ValidateCoordinates(newX, newY, false))
            {
                var piece = this[newX, newY];
                if (piece != null)
                {
                    yield return piece;
                }
            }

            newX = x;
            newY = y - 1;
            if (this.ValidateCoordinates(newX, newY, false))
            {
                var piece = this[newX, newY];
                if (piece != null)
                {
                    yield return piece;
                }
            }
        }

        private void CreatePieces()
        {
            var colors = new PieceColor[] { PieceColor.White, PieceColor.Black };
            foreach (var color in colors)
            {
                this.availablePieces.Add(new Piece(color, PieceType.FiveStarsGeneral));
                this.availablePieces.Add(new Piece(color, PieceType.FourStarsGeneral));
                this.availablePieces.Add(new Piece(color, PieceType.ThreeStarsGeneral));
                this.availablePieces.Add(new Piece(color, PieceType.TwoStarsGeneral));
                this.availablePieces.Add(new Piece(color, PieceType.OneStarGeneral));
                this.availablePieces.Add(new Piece(color, PieceType.Colonel));
                this.availablePieces.Add(new Piece(color, PieceType.LtColonel));
                this.availablePieces.Add(new Piece(color, PieceType.Major));
                this.availablePieces.Add(new Piece(color, PieceType.Captain));
                this.availablePieces.Add(new Piece(color, PieceType.FirstLieutenant));
                this.availablePieces.Add(new Piece(color, PieceType.SecondLieutenant));
                this.availablePieces.Add(new Piece(color, PieceType.Sergeant));
                this.availablePieces.Add(new Piece(color, PieceType.Spy));
                this.availablePieces.Add(new Piece(color, PieceType.Spy));
                this.availablePieces.Add(new Piece(color, PieceType.Private));
                this.availablePieces.Add(new Piece(color, PieceType.Private));
                this.availablePieces.Add(new Piece(color, PieceType.Private));
                this.availablePieces.Add(new Piece(color, PieceType.Private));
                this.availablePieces.Add(new Piece(color, PieceType.Private));
                this.availablePieces.Add(new Piece(color, PieceType.Private));
                this.availablePieces.Add(new Piece(color, PieceType.Flag));
            }
        }

        #endregion
    }
}

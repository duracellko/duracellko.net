﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication
{
    [ServiceContract(Namespace = Namespaces.ServiceNamespace, SessionMode = SessionMode.Required)]
    public interface IGameCallback : IGameCommunication
    {
        [OperationContract(IsOneWay = true, IsInitiating = false)]
        void Accept(string username);

        [OperationContract(IsOneWay = true, IsInitiating = false, IsTerminating = true)]
        void Reject();
    }
}

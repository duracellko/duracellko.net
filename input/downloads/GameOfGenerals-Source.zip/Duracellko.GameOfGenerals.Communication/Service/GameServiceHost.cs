﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Service
{
    internal class GameServiceHost : ServiceHost
    {
        public GameServiceHost(IGameRequestHandler gameRequestHandler, TaskScheduler taskScheduler, Type serviceType, params Uri[] baseAddresses)
            : base(serviceType, baseAddresses)
        {
            if (gameRequestHandler == null)
            {
                throw new ArgumentNullException("gameRequestHandler");
            }

            foreach (ContractDescription description in this.ImplementedContracts.Values)
            {
                if (description.ContractType == typeof(IGameService))
                {
                    var item = new GameServiceContractBehavior(new GameInstanceProvider(gameRequestHandler) { TaskScheduler = taskScheduler });
                    description.Behaviors.Add(item);
                }
            }
        }
    }
}

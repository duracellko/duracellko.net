﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Service
{
    internal class GameInstanceProvider : IInstanceProvider
    {
        private readonly IGameRequestHandler gameRequestHandler;

        public GameInstanceProvider(IGameRequestHandler gameRequestHandler)
        {
            this.gameRequestHandler = gameRequestHandler;
        }

        public TaskScheduler TaskScheduler { get; set; }

        public object GetInstance(InstanceContext instanceContext, Message message)
        {
            return new WcfGameService(this.gameRequestHandler) { TaskScheduler = this.TaskScheduler };
        }

        public object GetInstance(InstanceContext instanceContext)
        {
            return this.GetInstance(instanceContext, null);
        }

        public void ReleaseInstance(InstanceContext instanceContext, object instance)
        {
            // nothing to be released
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication.Service
{
    public abstract class GameServiceBase : GameCommunicationBase, IGameService, IGameRequestCallback
    {
        #region Fields

        private readonly IGameRequestHandler gameRequestHandler;

        private IGameCallback gameCallback;

        #endregion

        #region Constructor

        public GameServiceBase(IGameRequestHandler gameRequestHandler)
        {
            if (gameRequestHandler == null)
            {
                throw new ArgumentNullException("gameRequestHandler");
            }

            this.gameRequestHandler = gameRequestHandler;
        }

        #endregion

        #region IGameService

        public void RequestGame(string username, PieceColor color)
        {
            if (string.IsNullOrEmpty(username))
            {
                throw new ArgumentNullException("username");
            }

            if (this.Game != null)
            {
                throw new InvalidOperationException();
            }

            this.gameCallback = this.GetGameCallback();

            var action = new Action(() =>
                {
                    this.gameRequestHandler.HandleGameRequest(username, color, this);
                });

            this.SynchronizeAction(action);
        }

        #endregion

        #region IGameCallback

        public void Accept(IGameController game, string username)
        {
            if (game == null)
            {
                throw new ArgumentNullException("game");
            }

            this.Game = game;
            this.ExecuteCallbackAction(callback => callback.Accept(username));
        }

        public void Reject()
        {
            this.ExecuteCallbackAction(callback => callback.Reject());
        }

        #endregion

        #region Protected methods

        protected abstract IGameCallback GetGameCallback();

        protected override void ExecuteCommunicationAction(Action<IGameCommunication> action)
        {
            this.ExecuteCallbackAction(action);
        }

        #endregion

        #region Private methods

        private void ExecuteCallbackAction(Action<IGameCallback> action)
        {
            if (action == null)
            {
                throw new ArgumentNullException("action");
            }

            if (this.gameCallback != null)
            {
                var callback = this.gameCallback;
                Task.Factory.StartNew(() => action(callback));
            }
        }

        #endregion
    }
}

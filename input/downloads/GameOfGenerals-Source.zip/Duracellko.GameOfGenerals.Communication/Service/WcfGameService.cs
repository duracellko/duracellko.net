﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Service
{
    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Single, InstanceContextMode = InstanceContextMode.PerSession)]
    public class WcfGameService : GameServiceBase
    {
        public WcfGameService(IGameRequestHandler gameRequestHandler)
            : base(gameRequestHandler)
        {
        }

        protected override IGameCallback GetGameCallback()
        {
            return OperationContext.Current.GetCallbackChannel<IGameCallback>();
        }
    }
}

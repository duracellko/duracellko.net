﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Service
{
    public interface IGameServiceHostFactory
    {
        IDisposable CreateServiceHost(IGameRequestHandler requestHandler);

        Uri GetListenerUri(IDisposable serviceHost);
    }
}

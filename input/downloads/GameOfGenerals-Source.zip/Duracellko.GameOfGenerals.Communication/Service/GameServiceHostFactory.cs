﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Service
{
    public class GameServiceHostFactory : IGameServiceHostFactory
    {
        public TaskScheduler TaskScheduler { get; set; }

        public IDisposable CreateServiceHost(IGameRequestHandler requestHandler)
        {
            if (requestHandler == null)
            {
                throw new ArgumentNullException("requestHandler");
            }

            var host = new GameServiceHost(requestHandler, this.TaskScheduler, typeof(WcfGameService), new Uri(Namespaces.ServiceUri));

            var binding = new NetTcpBinding();
            binding.Namespace = Namespaces.ServiceNamespace;
            binding.Name = "GameOfGeneralsServiceBinding";
            binding.Security.Mode = SecurityMode.None;
            var sp = host.AddServiceEndpoint(typeof(IGameService), binding, string.Empty);
            sp.ListenUriMode = ListenUriMode.Unique;

            host.Open();
            return host;
        }

        public Uri GetListenerUri(IDisposable serviceHost)
        {
            var host = serviceHost as ServiceHostBase;
            if (host == null)
            {
                return null;
            }

            var bindingName = Namespaces.ServiceNamespace + ":GameOfGeneralsServiceBinding";
            var channelDispatcher = host.ChannelDispatchers.OfType<ChannelDispatcher>().FirstOrDefault(cd => cd.BindingName == bindingName);
            return channelDispatcher != null ? channelDispatcher.Listener.Uri : null;
        }
    }
}

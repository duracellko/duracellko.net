﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication
{
    internal static class Namespaces
    {
        public const string ServiceNamespace = "http://duracellko.net/GameOfGenerals/Service";

        public const string DataNamespace = "http://duracellko.net/GameOfGenerals/Data";

        public const string ServiceUri = "net.tcp://localhost/Duracellko/GameOfGenerals";

        public const string ServiceUriPattern = "net.tcp://{0}/Duracellko/GameOfGenerals";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    [DataContract(Namespace = Namespaces.DataNamespace)]
    public class PiecePosition
    {
        [DataMember]
        public int X { get; set; }

        [DataMember]
        public int Y { get; set; }

        [DataMember]
        public PieceType PieceType { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    public interface IGameConnectionManager : IDisposable
    {
        string Name { get; }

        IGameController GameController { get; }

        event EventHandler<GameConnectionEventArgs> GameConnectionFound;

        event EventHandler<GameConnectionEventArgs> GameRequested;

        event EventHandler<GameConnectionEventArgs> GameRequestAccepted;

        event EventHandler GameRequestRejected;

        void PublishMyName(string name);

        void Connect(string address);

        void Accept();

        void Reject();
    }
}

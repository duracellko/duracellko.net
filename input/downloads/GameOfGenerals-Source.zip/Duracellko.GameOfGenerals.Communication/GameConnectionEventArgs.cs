﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication
{
    public class GameConnectionEventArgs : EventArgs
    {
        public GameConnectionEventArgs(string address, string name)
        {
            this.Address = address;
            this.Name = name;
        }

        public string Address { get; private set; }

        public string Name { get; private set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication
{
    public interface IGameCallbackHandler
    {
        void HandleRequestGameCallback(bool accept, string username);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication.Client
{
    public class WcfGameClientCallback : GameClientCallbackBase
    {
        public WcfGameClientCallback(IGameCallbackHandler gameCallbackHandler, IGameController gameController)
            : base(gameCallbackHandler, gameController)
        {
        }
        
        public IGameCommunication GameCommunication { get; set; }

        protected override void ExecuteCommunicationAction(Action<IGameCommunication> action)
        {
            if (action == null)
            {
                throw new ArgumentNullException("action");
            }

            if (this.GameCommunication != null)
            {
                var gameCommunication = this.GameCommunication;
                Task.Factory.StartNew(() => action(gameCommunication));
            }
        }
    }
}

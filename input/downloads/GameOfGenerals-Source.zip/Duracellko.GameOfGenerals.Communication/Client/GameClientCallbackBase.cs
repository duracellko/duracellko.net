﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication.Client
{
    public abstract class GameClientCallbackBase : GameCommunicationBase, IGameCallback
    {
        #region Fields

        private readonly IGameCallbackHandler gameCallbackHandler;

        #endregion

        #region Constructor

        public GameClientCallbackBase(IGameCallbackHandler gameCallbackHandler, IGameController gameController)
        {
            if (gameCallbackHandler == null)
            {
                throw new ArgumentNullException("gameCallbackHandler");
            }

            if (gameController == null)
            {
                throw new ArgumentNullException("gameController");
            }

            this.gameCallbackHandler = gameCallbackHandler;
            this.Game = gameController;
        }

        #endregion

        #region IGameCallback

        public void Accept(string username)
        {
            var action = new Action(() =>
                {
                    this.gameCallbackHandler.HandleRequestGameCallback(true, username);
                });

            this.SynchronizeAction(action);
        }

        public void Reject()
        {
            var action = new Action(() =>
                {
                    this.gameCallbackHandler.HandleRequestGameCallback(false, null);
                });

            this.SynchronizeAction(action);
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication.Client
{
    public class WcfGameClient : ClientBase<IGameService>, IGameService
    {
        #region Constructor

        public WcfGameClient(InstanceContext callbackInstance, string remoteAddress)
            : base(callbackInstance, GetBinding(), new EndpointAddress(GetPortLessUri(remoteAddress)))
        {
            SetClientViaBehavior(new Uri(remoteAddress));
        }

        public WcfGameClient(InstanceContext callbackInstance, Uri remoteAddress)
            : base(callbackInstance, GetBinding(), new EndpointAddress(GetPortLessUri(remoteAddress)))
        {
            SetClientViaBehavior(remoteAddress);
        }

        #endregion

        #region IGameService

        public void RequestGame(string username, PieceColor color)
        {
            this.ExecuteAsyncAction(() => this.Channel.RequestGame(username, color));
        }

        public void MovePiece(int x, int y, MoveDirection direction)
        {
            this.ExecuteAsyncAction(() => this.Channel.MovePiece(x, y, direction));
        }

        public void SetPieces(PieceColor color, PiecePosition[] piecePositions)
        {
            this.ExecuteAsyncAction(() => this.Channel.SetPieces(color, piecePositions));
        }

        #endregion

        #region Private methods

        private static Binding GetBinding()
        {
            var binding = new NetTcpBinding();
            binding.Namespace = Namespaces.ServiceNamespace;
            binding.Name = "GameOfGeneralsClientBinding";
            binding.Security.Mode = SecurityMode.None;
            return binding;
        }

        private static Uri GetPortLessUri(string uri)
        {
            return GetPortLessUri(new Uri(uri));
        }

        private static Uri GetPortLessUri(Uri uri)
        {
            var uriBuilder = new UriBuilder(uri);
            uriBuilder.Port = -1;
            return uriBuilder.Uri;
        }

        private void SetClientViaBehavior(Uri viaUri)
        {
            this.Endpoint.Behaviors.Add(new ClientViaBehavior(viaUri));
        }

        private void ExecuteAsyncAction(Action action)
        {
            if (action == null)
            {
                throw new ArgumentNullException("action");
            }

            Task.Factory.StartNew(action);
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication.Client
{
    public class GameClientFactory : IGameClientFactory
    {
        public TaskScheduler TaskScheduler { get; set; }

        public IGameService CreateGameClient(IGameCallbackHandler callbackHandler, IGameController gameController, string address)
        {
            if (callbackHandler == null)
            {
                throw new ArgumentNullException("callbackHandler");
            }

            if (gameController == null)
            {
                throw new ArgumentNullException("gameController");
            }

            var remoteAddress = string.Format(Namespaces.ServiceUriPattern, address);
            var clientCallback = new WcfGameClientCallback(callbackHandler, gameController);
            clientCallback.TaskScheduler = this.TaskScheduler;
            var instanceContext = new InstanceContext(clientCallback);
            var client = new WcfGameClient(instanceContext, remoteAddress);
            clientCallback.GameCommunication = client;
            return client;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    public abstract class GameCommunicationBase : IGameCommunication
    {
        #region Fields

        private IGameController gameController;
        private List<Piece> setupPiecesSent = new List<Piece>();

        #endregion

        #region Properties

        public IGameController Game
        {
            get { return this.gameController; }
            protected set
            {
                if (value != this.gameController)
                {
                    if (this.gameController != null)
                    {
                        this.gameController.GameChanged -= this.GameOnGameChanged;
                        this.gameController.PieceMoved -= this.GameOnPieceMoved;
                    }

                    this.gameController = value;

                    if (this.gameController != null)
                    {
                        this.gameController.GameChanged += this.GameOnGameChanged;
                        this.gameController.PieceMoved += this.GameOnPieceMoved;
                    }                    
                }
            }
        }

        public TaskScheduler TaskScheduler { get; set; }

        #endregion

        #region IGameCommunication

        public void MovePiece(int x, int y, MoveDirection direction)
        {
            var action = new Action(() =>
                {
                    if (this.Game == null)
                    {
                        throw new InvalidOperationException();
                    }

                    if ((this.Game.MyColor == PieceColor.White && this.Game.State == GameState.BlackMoves) ||
                        (this.Game.MyColor == PieceColor.Black && this.Game.State == GameState.WhiteMoves))
                    {
                        this.Game.Move(x, y, direction);
                    }
                    else
                    {
                        throw new InvalidOperationException();
                    }
                });

            this.SynchronizeAction(action);
        }

        public void SetPieces(PieceColor color, PiecePosition[] piecePositions)
        {
            var action = new Action(() =>
                {
                    if (this.Game == null)
                    {
                        throw new InvalidOperationException();
                    }

                    if (this.Game.State != GameState.Setup)
                    {
                        throw new InvalidOperationException();
                    }

                    if (this.Game.MyColor == color)
                    {
                        throw new InvalidOperationException();
                    }

                    if (piecePositions == null)
                    {
                        return;
                    }

                    foreach (var piecePosition in piecePositions)
                    {
                        var piece = this.Game.AvailablePieces.FirstOrDefault(p => p.Color == color && p.Type == piecePosition.PieceType);
                        if (piece != null)
                        {
                            this.Game.SetupPiece(piece, piecePosition.X, piecePosition.Y);
                        }
                    }
                });

            this.SynchronizeAction(action);
        }

        #endregion

        #region Protected methods

        protected abstract void ExecuteCommunicationAction(Action<IGameCommunication> action);

        protected async void SynchronizeAction(Action action)
        {
            if (action == null)
            {
                throw new ArgumentNullException("action");
            }

            if (this.TaskScheduler == null)
            {
                action();
            }
            else
            {
                var factory = Task.Factory;
                await factory.StartNew(action, factory.CancellationToken, factory.CreationOptions, this.TaskScheduler);
            }
        }

        #endregion

        #region Private methods

        private void GameOnGameChanged(object sender, EventArgs e)
        {
            if (this.Game.State == GameState.Setup)
            {
                if (!this.Game.AvailablePieces.Any(p => p.Color == this.Game.MyColor))
                {
                    var piecePositions = new List<PiecePosition>();
                    for (int x = 0; x < this.Game.Columns; x++)
                    {
                        for (int y = 0; y < this.Game.Rows; y++)
                        {
                            var piece = this.Game[x, y];
                            if (piece != null && piece.Color == this.Game.MyColor && !this.setupPiecesSent.Contains(piece))
                            {
                                this.setupPiecesSent.Add(piece);
                                piecePositions.Add(new PiecePosition() { X = x, Y = y, PieceType = piece.Type });
                            }
                        }
                    }

                    if (piecePositions.Count != 0)
                    {
                        this.ExecuteCommunicationAction(c => c.SetPieces(this.Game.MyColor, piecePositions.ToArray()));
                    }
                }
            }
        }

        private void GameOnPieceMoved(object sender, PieceMovedEventArgs e)
        {
            if ((this.Game.MyColor == PieceColor.White && this.Game.State == GameState.WhiteMoves) ||
                (this.Game.MyColor == PieceColor.Black && this.Game.State == GameState.BlackMoves))
            {
                this.ExecuteCommunicationAction(c => c.MovePiece(e.X, e.Y, e.Direction));
            }
        }

        #endregion
    }
}

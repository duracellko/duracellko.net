﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    [ServiceContract(Namespace = Namespaces.ServiceNamespace, SessionMode = SessionMode.Required, CallbackContract = typeof(IGameCallback))]
    public interface IGameService : IGameCommunication
    {
        [OperationContract(IsOneWay = true, IsInitiating = true)]
        void RequestGame(string username, PieceColor color);
    }
}

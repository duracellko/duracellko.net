﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    public interface IGameRequestCallback
    {
        void Accept(IGameController game, string username);

        void Reject();
    }
}

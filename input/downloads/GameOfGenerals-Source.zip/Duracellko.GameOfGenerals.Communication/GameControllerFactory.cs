﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    public class GameControllerFactory : IGameControllerFactory
    {
        public IGameController Create(PieceColor color)
        {
            return new GameController(color);
        }
    }
}

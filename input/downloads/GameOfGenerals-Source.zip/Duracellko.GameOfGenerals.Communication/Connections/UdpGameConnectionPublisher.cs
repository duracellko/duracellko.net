﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Connections
{
    public class UdpGameConnectionPublisher : IGameConnectionPublisher
    {
        #region Fields

        private const int UdpPort = 6322;
        private static readonly byte[] datagramPrefix = Encoding.ASCII.GetBytes("GameOfGenerals");

        private readonly int servicePort;
        private UdpClient udpClient;

        #endregion

        #region Constructor

        public UdpGameConnectionPublisher(string name, int servicePort)
        {
            this.Name = name;
            this.servicePort = servicePort;
        }

        #endregion

        #region Properties

        public string Name { get; private set; }

        public event EventHandler<GameConnectionEventArgs> GameConnectionFound;

        #endregion

        #region Public methods

        public void PublishMyName(string name)
        {
            if (name != null)
            {
                this.Name = name;
            }

            this.CreateClient();
            this.SendMyName(IPAddress.Broadcast, true);
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (this.udpClient != null)
                {
                    this.udpClient.Close();
                    this.udpClient = null;
                }
            }
        }

        #endregion

        #region Private methods

        private void ExecuteGameConnectionFound(string address, string name)
        {
            var eventArgs = new GameConnectionEventArgs(address, name);
            if (this.GameConnectionFound != null)
            {
                this.GameConnectionFound(this, eventArgs);
            }
        }

        #endregion

        #region Private methods

        private void CreateClient()
        {
            if (this.udpClient == null)
            {
                this.udpClient = new UdpClient();
                this.udpClient.ExclusiveAddressUse = false;
                this.udpClient.EnableBroadcast = true;
                this.udpClient.DontFragment = true;
                this.udpClient.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                this.udpClient.Client.Bind(new IPEndPoint(IPAddress.Any, UdpPort));

                this.ReceiveData();
            }
        }

        private async void ReceiveData()
        {
            while (this.udpClient != null)
            {
                UdpReceiveResult? receivedResult = null;
                try
                {
                    receivedResult = await this.udpClient.ReceiveAsync();
                }
                catch (ObjectDisposedException)
                {
                    break;
                }

                if (receivedResult.HasValue)
                {
                    var result = receivedResult.Value;
                    try
                    {
                        int nameStartIndex = datagramPrefix.Length + 5;
                        if (result.Buffer.Length > nameStartIndex)
                        {
                            byte requestRemoteGames = result.Buffer[datagramPrefix.Length];
                            int gamePort = BitConverter.ToInt32(result.Buffer, datagramPrefix.Length + 1);
                            string gameName = Encoding.Unicode.GetString(result.Buffer, nameStartIndex, result.Buffer.Length - nameStartIndex);
                            var remoteServiceEndpoint = new IPEndPoint(result.RemoteEndPoint.Address, gamePort);

                            this.ExecuteGameConnectionFound(remoteServiceEndpoint.ToString(), gameName);

                            if (requestRemoteGames != 0)
                            {
                                this.SendMyName(result.RemoteEndPoint.Address, false);
                            }
                        }
                    }
                    catch (Exception)
                    {
                        // drop incorrect packets
                    }
                }
            }
        }

        private void SendMyName(IPAddress address, bool requestRemoteGames)
        {
            if (this.Name != null)
            {
                var portBytes = BitConverter.GetBytes(this.servicePort);
                var encoding = Encoding.Unicode;
                var bytesCount = encoding.GetByteCount(this.Name);
                var buffer = new byte[datagramPrefix.Length + portBytes.Length + bytesCount + 1];

                for (int i = 0; i < datagramPrefix.Length; i++)
                {
                    buffer[i] = datagramPrefix[i];
                }

                buffer[datagramPrefix.Length] = (byte)(requestRemoteGames ? 1 : 0);

                for (int i = 0; i < portBytes.Length; i++)
                {
                    buffer[i + datagramPrefix.Length + 1] = portBytes[i];
                }

                encoding.GetBytes(this.Name, 0, this.Name.Length, buffer, datagramPrefix.Length + portBytes.Length + 1);

                var endPoint = new IPEndPoint(address, UdpPort);
                udpClient.SendAsync(buffer, buffer.Length, endPoint);
            }
        }

        #endregion
    }
}

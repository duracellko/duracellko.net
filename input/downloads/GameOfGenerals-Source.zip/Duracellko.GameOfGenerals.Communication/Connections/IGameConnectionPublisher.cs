﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Connections
{
    public interface IGameConnectionPublisher : IDisposable
    {
        string Name { get; }

        event EventHandler<GameConnectionEventArgs> GameConnectionFound;

        void PublishMyName(string name);
    }
}

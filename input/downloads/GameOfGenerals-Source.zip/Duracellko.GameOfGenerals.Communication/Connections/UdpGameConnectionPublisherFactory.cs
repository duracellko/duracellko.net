﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.Communication.Connections
{
    public class UdpGameConnectionPublisherFactory : IGameConnectionPublisherFactory
    {
        public IGameConnectionPublisher Create(string name, int servicePort)
        {
            return new UdpGameConnectionPublisher(name, servicePort);
        }
    }
}

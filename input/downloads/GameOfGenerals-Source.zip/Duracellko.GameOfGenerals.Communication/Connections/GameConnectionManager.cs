﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Communication.Client;
using Duracellko.GameOfGenerals.Communication.Service;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication.Connections
{
    public class GameConnectionManager : IGameConnectionManager, IGameRequestHandler, IGameCallbackHandler
    {
        #region Fields

        private readonly Random random = new Random();

        private IGameConnectionPublisher connectionPublisher;
        private IDisposable serviceHost;
        private IGameRequestCallback gameRequestCallback;
        private IGameService gameClient;
        private int servicePort;

        #endregion

        #region Constructor

        public GameConnectionManager(
            IGameControllerFactory gameControllerFactory,
            IGameServiceHostFactory serviceHostFactory,
            IGameClientFactory gameClientFactory,
            IGameConnectionPublisherFactory connectionPublisherFactory)
        {
            if (gameControllerFactory == null)
            {
                throw new ArgumentNullException("gameControllerFactory");
            }

            if (serviceHostFactory == null)
            {
                throw new ArgumentNullException("serviceHostFactory");
            }

            if (gameClientFactory == null)
            {
                throw new ArgumentNullException("gameClientFactory");
            }

            if (connectionPublisherFactory == null)
            {
                throw new ArgumentNullException("connectionPublisherFactory");
            }

            this.GameControllerFactory = gameControllerFactory;
            this.GameServiceHostFactory = serviceHostFactory;
            this.GameClientFactory = gameClientFactory;
            this.GameConnectionPublisherFactory = connectionPublisherFactory;
            this.Name = Environment.UserName;

            this.serviceHost = this.GameServiceHostFactory.CreateServiceHost(this);

            var serviceUri = this.GameServiceHostFactory.GetListenerUri(serviceHost);
            this.servicePort = serviceUri.Port;
            this.connectionPublisher = this.GameConnectionPublisherFactory.Create(this.Name, this.servicePort);
            this.connectionPublisher.GameConnectionFound += this.UdpConnectionManagerOnGameConnectionFound;
        }

        #endregion

        #region Properties

        public IGameControllerFactory GameControllerFactory { get; private set; }

        public IGameServiceHostFactory GameServiceHostFactory { get; private set; }

        public IGameClientFactory GameClientFactory { get; private set; }

        public IGameConnectionPublisherFactory GameConnectionPublisherFactory { get; private set; }

        public IGameController GameController { get; private set; }

        public TaskScheduler TaskScheduler { get; set; }

        #endregion

        #region IGameConnectionManager

        public string Name { get; private set; }

        public event EventHandler<GameConnectionEventArgs> GameConnectionFound;

        protected virtual void OnGameConnectionFound(GameConnectionEventArgs e)
        {
            if (this.GameConnectionFound != null)
            {
                this.GameConnectionFound(this, e);
            }
        }

        public event EventHandler<GameConnectionEventArgs> GameRequested;

        protected virtual void OnGameRequested(GameConnectionEventArgs e)
        {
            if (this.GameRequested != null)
            {
                this.GameRequested(this, e);
            }
        }

        public event EventHandler<GameConnectionEventArgs> GameRequestAccepted;

        protected virtual void OnGameRequestAccepted(GameConnectionEventArgs e)
        {
            if (this.GameRequestAccepted != null)
            {
                this.GameRequestAccepted(this, e);
            }
        }

        public event EventHandler GameRequestRejected;

        protected virtual void OnGameRequestRejected(EventArgs e)
        {
            if (this.GameRequestRejected != null)
            {
                this.GameRequestRejected(this, e);
            }
        }

        public void PublishMyName(string name)
        {
            if (name != null)
            {
                this.Name = name;
            }

            this.connectionPublisher.PublishMyName(this.Name);
        }

        public void Connect(string address)
        {
            if (string.IsNullOrEmpty(address))
            {
                throw new ArgumentNullException("address");
            }

            this.CreateGameController(this.GetRandomColor());
            this.gameClient = this.GameClientFactory.CreateGameClient(this, this.GameController, address);
            this.gameClient.RequestGame(this.Name, this.GameController.MyColor);
        }

        public void Accept()
        {
            if (this.gameRequestCallback == null)
            {
                throw new InvalidOperationException();
            }

            this.gameRequestCallback.Accept(this.GameController, this.Name);
            this.gameRequestCallback = null;
        }

        public void Reject()
        {
            if (this.gameRequestCallback == null)
            {
                throw new InvalidOperationException();
            }

            this.gameRequestCallback.Reject();
            this.gameRequestCallback = null;
            this.GameController = null;
        }

        #endregion

        #region IGameRequestHandler

        public void HandleGameRequest(string username, PieceColor color, IGameRequestCallback callback)
        {
            if (this.GameController != null)
            {
                throw new InvalidOperationException();
            }

            this.CreateGameController(Duracellko.GameOfGenerals.Domain.GameController.GetOppositeColor(color));
            this.gameRequestCallback = callback;
            this.OnGameRequested(new GameConnectionEventArgs(string.Empty, username));
        }

        #endregion

        #region IGameCallbackHandler

        public void HandleRequestGameCallback(bool accept, string username)
        {
            if (accept)
            {
                this.OnGameRequestAccepted(new GameConnectionEventArgs(string.Empty, username));
            }
            else
            {
                this.CloseGameClient();
                this.GameController = null;
                this.OnGameRequestRejected(EventArgs.Empty);
            }
        }

        #endregion

        #region IDisposable

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                this.CloseGameClient();

                if (this.serviceHost != null)
                {
                    this.serviceHost.Dispose();
                    this.serviceHost = null;
                }

                if (this.connectionPublisher != null)
                {
                    this.connectionPublisher.GameConnectionFound -= this.UdpConnectionManagerOnGameConnectionFound;
                    this.connectionPublisher.Dispose();
                    this.connectionPublisher = null;
                }
            }
        }

        #endregion

        #region Private methods

        private void UdpConnectionManagerOnGameConnectionFound(object sender, GameConnectionEventArgs e)
        {
            if (string.IsNullOrEmpty(e.Address))
            {
                return;
            }

            this.SynchronizeAction(() => 
                {
                    var uri = new Uri(string.Format("net.tcp://{0}/Duracellko", e.Address));
                    if (uri.Port != this.servicePort || !string.Equals(e.Name, this.Name, StringComparison.OrdinalIgnoreCase))
                    {
                        this.OnGameConnectionFound(e);
                    }
                });
        }

        private void CreateGameController(PieceColor color)
        {
            this.GameController = this.GameControllerFactory.Create(color);
        }

        private async void SynchronizeAction(Action action)
        {
            if (action == null)
            {
                throw new ArgumentNullException("action");
            }

            if (this.TaskScheduler == null)
            {
                action();
            }
            else
            {
                var factory = Task.Factory;
                await factory.StartNew(action, factory.CancellationToken, factory.CreationOptions, this.TaskScheduler);
            }
        }

        private void CloseGameClient()
        {
            if (this.gameClient != null)
            {
                var disposableClient = this.gameClient as IDisposable;
                if (disposableClient != null)
                {
                    disposableClient.Dispose();
                }

                this.gameClient = null;
            }
        }

        private PieceColor GetRandomColor()
        {
            return (this.random.Next() & 1) != 0 ? PieceColor.White : PieceColor.Black;
        }

        #endregion
    }
}

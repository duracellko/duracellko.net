﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.Communication
{
    [ServiceContract(Namespace = Namespaces.ServiceNamespace, CallbackContract = typeof(IGameCommunication))]
    public interface IGameCommunication
    {
        [OperationContract(IsOneWay = true, IsInitiating = false)]
        void MovePiece(int x, int y, MoveDirection direction);

        [OperationContract(IsOneWay = true, IsInitiating = false)]
        void SetPieces(PieceColor color, PiecePosition[] piecePositions);
    }
}

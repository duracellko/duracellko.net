﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;
using GalaSoft.MvvmLight;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class BoardViewModel : ViewModelBase
    {
        #region Fields

        private readonly IGameController gameController;
        private readonly ObservableCollection<FieldViewModel> fields = new ObservableCollection<FieldViewModel>();

        #endregion

        #region Constructor

        public BoardViewModel(GameViewModel parent, IGameController gameController)
        {
            if (parent == null)
            {
                throw new ArgumentNullException("parent");
            }

            if (gameController == null)
            {
                throw new ArgumentNullException("gameController");
            }

            this.Parent = parent;
            this.gameController = gameController;

            this.gameController.GameChanged += this.GameControllerOnGameChanged;
            this.gameController.PieceMoved += this.GameControllerOnPieceMoved;
        }

        #endregion

        #region Properties

        public GameViewModel Parent { get; private set; }

        public int Columns
        {
            get { return this.gameController.Columns; }
        }

        public int Rows
        {
            get { return this.gameController.Rows; }
        }

        public IReadOnlyList<FieldViewModel> Fields
        {
            get { return this.fields; }
        }

        #endregion

        #region Public methods

        public void InitializeSetup()
        {
            for (int i = 0; i < this.Columns; i++)
            {
                for (int j = this.Rows / 2; j < this.Rows; j++)
                {
                    this.fields.Add(new SetupFieldViewModel(this, i, j));
                }
            }
        }

        public void SetPiece(PieceItem piece, SetupFieldViewModel field)
        {
            if (piece == null)
            {
                throw new ArgumentNullException("piece");
            }

            if (field == null)
            {
                throw new ArgumentNullException("field");
            }

            bool fromAvailablePieces = this.Parent.MyAvailablePieces.Remove(piece);
            PieceFieldViewModel originalField = null;
            if (!fromAvailablePieces)
            {
                var pieceFields = this.fields.OfType<PieceFieldViewModel>();
                originalField = pieceFields.FirstOrDefault(f => f.Piece == piece);
                if (originalField != null)
                {
                    this.RemoveFields<PieceFieldViewModel>(f => f.Piece.Piece == piece.Piece);
                }
            }

            if (fromAvailablePieces || originalField != null)
            {
                this.fields.Remove(field);

                if (originalField != null)
                {
                    var newSetupField = new SetupFieldViewModel(this, originalField.X, originalField.Y);
                    this.fields.Add(newSetupField);
                }

                var pieceField = new PieceFieldViewModel(this, piece.Piece, field.X, field.Y);
                var pieceDragField = new PieceDragFieldViewModel(this, piece.Piece, field.X, field.Y);
                this.fields.Add(pieceField);
                this.fields.Add(pieceDragField);
            }
        }

        public void CommitSetupPieces()
        {
            this.RemoveFields<FieldViewModel>(f => f.GetType() != typeof(PieceFieldViewModel));

            foreach (var pieceField in this.fields.OfType<PieceFieldViewModel>().ToList())
            {
                if (pieceField.Piece.Color == this.gameController.MyColor)
                {
                    this.gameController.SetupPiece(pieceField.Piece.Piece, this.GetGameColumn(pieceField.X), this.GetGameRow(pieceField.Y));
                }
            }
        }

        public void SelectPiece(SelectFieldViewModel field)
        {
            if (field == null)
            {
                throw new ArgumentNullException("field");
            }

            this.RemoveFields<SelectFieldViewModel>(null);

            var x = this.GetGameColumn(field.X);
            var y = this.GetGameRow(field.Y);
            this.fields.Add(new SelectedFieldViewModel(this, field.X, field.Y));
            this.CreateSelectDirectionField(x, y, MoveDirection.Forward);
            this.CreateSelectDirectionField(x, y, MoveDirection.Left);
            this.CreateSelectDirectionField(x, y, MoveDirection.Right);
            this.CreateSelectDirectionField(x, y, MoveDirection.Backward);
        }

        public void UnselectPiece(SelectedFieldViewModel field)
        {
            if (field == null)
            {
                throw new ArgumentNullException("field");
            }

            this.RemoveFields<SelectDirectionFieldViewModel>(null);
            this.RemoveFields<SelectedFieldViewModel>(null);
            this.CreateSelectFields();
        }

        public void MovePiece(SelectDirectionFieldViewModel field)
        {
            if (field == null)
            {
                throw new ArgumentNullException("field");
            }

            var selectedPiece = this.fields.OfType<SelectedFieldViewModel>().FirstOrDefault();
            if (selectedPiece != null)
            {
                this.RemoveFields<SelectDirectionFieldViewModel>(null);
                this.RemoveFields<SelectedFieldViewModel>(null);

                var x = this.GetGameColumn(selectedPiece.X);
                var y = this.GetGameRow(selectedPiece.Y);
                this.gameController.Move(x, y, field.Direction);
            }
        }

        public override void Cleanup()
        {
            this.gameController.GameChanged -= this.GameControllerOnGameChanged;
            this.gameController.PieceMoved -= this.GameControllerOnPieceMoved;

            base.Cleanup();
        }

        #endregion

        #region Private methods

        private void GameControllerOnGameChanged(object sender, EventArgs e)
        {
            switch (this.gameController.State)
            {
                case GameState.Setup:
                    if (!this.gameController.AvailablePieces.Any())
                    {
                        this.CreateOpponentPieceFields();
                    }
                    break;
                case GameState.WhiteMoves:
                    if (this.gameController.MyColor == PieceColor.White)
                    {
                        this.CreateSelectFields();
                    }
                    break;
                case GameState.BlackMoves:
                    if (this.gameController.MyColor == PieceColor.Black)
                    {
                        this.CreateSelectFields();
                    }
                    break;
            }
        }

        private void GameControllerOnPieceMoved(object sender, PieceMovedEventArgs e)
        {
            var newPosition = this.gameController.GetMoveCoordinates(e.X, e.Y, e.Direction, true);
            var piece = this.gameController[newPosition.X, newPosition.Y];

            var pieceFields = this.fields.OfType<PieceFieldViewModel>();
            var pieceField = pieceFields.First(f => this.GetGameColumn(f.X) == e.X && this.GetGameRow(f.Y) == e.Y);
            pieceField.Move(this.GetViewColumn(newPosition.X), this.GetViewRow(newPosition.Y));

            this.RemoveFields<PieceFieldViewModel>(f => this.GetGameColumn(f.X) == newPosition.X && this.GetGameRow(f.Y) == newPosition.Y && f.Piece.Piece != piece);

            this.RemoveFields<MoveInfoFieldViewModel>(null);
            this.fields.Add(new MoveInfoFieldViewModel(this, this.GetViewColumn(newPosition.X), this.GetViewRow(newPosition.Y)));
        }

        private void CreateOpponentPieceFields()
        {
            for (int x = 0; x < this.gameController.Columns; x++)
            {
                for (int y = 0; y < this.gameController.Rows; y++)
                {
                    var piece = this.gameController[x, y];
                    if (piece != null && piece.Color == this.gameController.OpponentColor)
                    {
                        this.fields.Add(new PieceFieldViewModel(this, piece, this.GetViewColumn(x), this.GetViewRow(y)) { Hidden = true });
                    }
                }
            }
        }

        private void CreateSelectFields()
        {
            for (int x = 0; x < this.gameController.Columns; x++)
            {
                for (int y = 0; y < this.gameController.Rows; y++)
                {
                    var piece = this.gameController[x, y];
                    if (piece != null && piece.Color == this.gameController.MyColor)
                    {
                        this.fields.Add(new SelectFieldViewModel(this, this.GetViewColumn(x), this.GetViewRow(y)));
                    }
                }
            }
        }

        private void CreateSelectDirectionField(int x, int y, MoveDirection direction)
        {
            if (this.gameController.CanMove(x, y, direction))
            {
                var moveCoordinates = this.gameController.GetMoveCoordinates(x, y, direction);
                var selectMoveField = new SelectDirectionFieldViewModel(this, direction, this.GetViewColumn(moveCoordinates.X), this.GetViewRow(moveCoordinates.Y));
                this.fields.Add(selectMoveField);
            }
        }

        private int GetViewColumn(int x)
        {
            return this.gameController.MyColor == PieceColor.Black ? this.Columns - x - 1 : x;
        }

        private int GetViewRow(int y)
        {
            return this.gameController.MyColor == PieceColor.White ? this.Rows - y - 1 : y;
        }

        private int GetGameColumn(int x)
        {
            return this.gameController.MyColor == PieceColor.Black ? this.Columns - x - 1 : x;
        }

        private int GetGameRow(int y)
        {
            return this.gameController.MyColor == PieceColor.White ? this.Rows - y - 1 : y;
        }

        private void RemoveFields<T>(Func<T, bool> predicate)
            where T : FieldViewModel
        {
            for (int i = this.fields.Count - 1; i >= 0; i--)
            {
                var field = this.fields[i] as T;
                if (field != null && (predicate == null || predicate(field)))
                {
                    this.fields.RemoveAt(i);
                }
            }
        }

        #endregion
    }
}

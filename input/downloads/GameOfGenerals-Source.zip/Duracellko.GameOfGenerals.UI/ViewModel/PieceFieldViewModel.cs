﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class PieceFieldViewModel : FieldViewModel
    {
        #region Constructor

        public PieceFieldViewModel(BoardViewModel parent, Piece piece)
            : base(parent)
        {
            if (piece == null)
            {
                throw new ArgumentNullException("piece");
            }

            this.Piece = new PieceItem(piece);
        }

        public PieceFieldViewModel(BoardViewModel parent, Piece piece, int x, int y)
            : base(parent, x, y)
        {
            if (piece == null)
            {
                throw new ArgumentNullException("piece");
            }

            this.Piece = new PieceItem(piece);
        }

        #endregion

        #region Properties

        public PieceItem Piece { get; private set; }

        public bool Hidden { get; set; }

        #endregion
    }
}

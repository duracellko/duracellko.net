﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class MoveInfoFieldViewModel : FieldViewModel
    {
        #region Constructor

        public MoveInfoFieldViewModel(BoardViewModel parent)
            : base(parent)
        {
        }

        public MoveInfoFieldViewModel(BoardViewModel parent, int x, int y)
            : base(parent, x, y)
        {
        }

        #endregion
    }
}

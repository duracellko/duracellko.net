﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class PieceDragFieldViewModel : PieceFieldViewModel
    {
        #region Constructor

        public PieceDragFieldViewModel(BoardViewModel parent, Piece piece)
            : base(parent, piece)
        {
        }

        public PieceDragFieldViewModel(BoardViewModel parent, Piece piece, int x, int y)
            : base(parent, piece, x, y)
        {
        }

        #endregion
    }
}

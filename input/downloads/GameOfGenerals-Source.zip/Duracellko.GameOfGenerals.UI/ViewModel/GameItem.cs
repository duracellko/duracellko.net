﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class GameItem : ObservableObject
    {
        #region Constructor

        public GameItem(string address, string name)
        {
            this.Address = address;
            this.name = name;
        }

        #endregion

        #region Properties

        public string Address { get; private set; }

        private string name;

        public string Name
        {
            get { return this.name; }
            set { this.Set(() => this.Name, ref this.name, value); }
        }

        #endregion
    }
}

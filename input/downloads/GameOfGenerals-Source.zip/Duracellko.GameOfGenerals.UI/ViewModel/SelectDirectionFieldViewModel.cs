﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Duracellko.GameOfGenerals.Domain;
using GalaSoft.MvvmLight.Command;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class SelectDirectionFieldViewModel : FieldViewModel
    {
        #region Constructor

        public SelectDirectionFieldViewModel(BoardViewModel parent, MoveDirection direction)
            : base(parent)
        {
            this.Initialize(direction);
        }

        public SelectDirectionFieldViewModel(BoardViewModel parent, MoveDirection direction, int x, int y)
            : base(parent, x, y)
        {
            this.Initialize(direction);
        }

        private void Initialize(MoveDirection direction)
        {
            this.Direction = direction;
            this.clickCommand = new RelayCommand(this.OnClickCommand);
        }

        #endregion

        #region Properties

        public MoveDirection Direction { get; private set; }

        #endregion

        #region Commands

        private RelayCommand clickCommand;

        public ICommand ClickCommand
        {
            get { return this.clickCommand; }
        }

        private void OnClickCommand()
        {
            this.Parent.MovePiece(this);
        }

        #endregion
    }
}

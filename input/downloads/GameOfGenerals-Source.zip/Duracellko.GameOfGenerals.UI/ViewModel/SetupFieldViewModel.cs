﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class SetupFieldViewModel : FieldViewModel
    {
        #region Constructor

        public SetupFieldViewModel(BoardViewModel parent)
            : base(parent)
        {
            this.Initialize();
        }

        public SetupFieldViewModel(BoardViewModel parent, int x, int y)
            : base(parent, x, y)
        {
            this.Initialize();
        }

        private void Initialize()
        {
            this.dropCommand = new RelayCommand<DragEventArgs>(this.OnDropCommand);
        }

        #endregion

        #region Commands

        private RelayCommand<DragEventArgs> dropCommand;

        public ICommand DropCommand
        {
            get { return this.dropCommand; }
        }

        private void OnDropCommand(DragEventArgs eventArgs)
        {
            if (eventArgs != null && eventArgs.Data.GetDataPresent(typeof(PieceItem)))
            {
                var pieceItem = (PieceItem)eventArgs.Data.GetData(typeof(PieceItem));
                this.Parent.SetPiece(pieceItem, this);
                eventArgs.Handled = true;
            }
        }

        #endregion

    }
}

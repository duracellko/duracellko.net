﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Duracellko.GameOfGenerals.Domain;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class GameViewModel : ViewModelBase
    {
        #region Fields

        private readonly IGameController gameController;
        private readonly ObservableCollection<PieceItem> myAvailablePieces = new ObservableCollection<PieceItem>();
        private readonly ObservableCollection<PieceItem> myEliminatedPieces = new ObservableCollection<PieceItem>();
        private readonly ObservableCollection<PieceItem> opponentEliminatedPieces = new ObservableCollection<PieceItem>();

        #endregion

        #region Constructor

        public GameViewModel(IGameController gameController)
        {
            if (gameController == null)
            {
                throw new ArgumentNullException("gameController");
            }

            this.gameController = gameController;
            this.endSetupCommand = new RelayCommand(this.OnEndSetupCommand, () => this.myAvailablePieces.Count == 0);
            this.Board = new BoardViewModel(this, this.gameController);

            this.gameController.GameChanged += this.GameControllerOnGameChanged;
            this.myAvailablePieces.CollectionChanged += this.MyAvailablePiecesOnCollectionChanged;
            this.Initialize();
        }

        #endregion

        #region Properties

        public BoardViewModel Board { get; private set; }

        public string State
        {
            get { return this.gameController.State.ToString(); }
        }

        public string MyColor
        {
            get { return this.gameController.MyColor.ToString(); }
        }

        public IList<PieceItem> MyAvailablePieces
        {
            get { return this.myAvailablePieces; }
        }

        private bool areMyAvailablePiecesVisible;

        public bool AreMyAvailablePiecesVisible
        {
            get { return this.areMyAvailablePiecesVisible; }
            private set { this.Set(() => this.AreMyAvailablePiecesVisible, ref this.areMyAvailablePiecesVisible, value); }
        }

        public IList<PieceItem> MyEliminatedPieces
        {
            get { return this.myEliminatedPieces; }
        }

        public IList<PieceItem> OpponentEliminatedPieces
        {
            get { return this.opponentEliminatedPieces; }
        }

        private bool areEliminatedPiecesVisible;

        public bool AreEliminatedPiecesVisible
        {
            get { return this.areEliminatedPiecesVisible; }
            private set { this.Set(() => this.AreEliminatedPiecesVisible, ref this.areEliminatedPiecesVisible, value); }
        }

        private bool isGameResultVisible;

        public bool IsGameResultVisible
        {
            get { return this.isGameResultVisible; }
            private set { this.Set(() => this.IsGameResultVisible, ref this.isGameResultVisible, value); }
        }

        private string gameResult;

        public string GameResult
        {
            get { return this.gameResult; }
            private set { this.Set(() => this.GameResult, ref this.gameResult, value); }
        }

        #endregion

        #region Commands

        private RelayCommand endSetupCommand;

        public ICommand EndSetupCommand
        {
            get { return this.endSetupCommand; }
        }

        #endregion

        #region Public methods

        public override void Cleanup()
        {
            this.Board.Cleanup();
            this.gameController.GameChanged -= this.GameControllerOnGameChanged;

            base.Cleanup();
        }

        #endregion

        #region Private methods

        private void OnEndSetupCommand()
        {
            this.Board.CommitSetupPieces();
            this.AreMyAvailablePiecesVisible = false;
            this.AreEliminatedPiecesVisible = true;
        }

        private void Initialize()
        {
            this.SetAvailablePieces();
            this.AreMyAvailablePiecesVisible = true;
            this.Board.InitializeSetup();
        }

        private void GameControllerOnGameChanged(object sender, EventArgs e)
        {
            this.RaisePropertyChanged(() => this.State);
            this.RefreshEliminatedPieces(this.myEliminatedPieces, this.gameController.MyColor);
            this.RefreshEliminatedPieces(this.opponentEliminatedPieces, this.gameController.OpponentColor);

            switch (this.gameController.State)
            {
                case GameState.WhiteWon:
                    this.GameResult = this.gameController.MyColor == PieceColor.White ? Properties.Resources.GameResultWin : Properties.Resources.GameResultLose;
                    this.IsGameResultVisible = true;
                    break;
                case GameState.BlackWon:
                    this.GameResult = this.gameController.MyColor == PieceColor.Black ? Properties.Resources.GameResultWin : Properties.Resources.GameResultLose;
                    this.IsGameResultVisible = true;
                    break;
            }
        }

        private void MyAvailablePiecesOnCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            this.endSetupCommand.RaiseCanExecuteChanged();
        }

        private void SetAvailablePieces()
        {
            var itemsToAdd = this.gameController.AvailablePieces.Where(p => p.Color == this.gameController.MyColor);
            foreach (var item in itemsToAdd)
            {
                this.myAvailablePieces.Add(new PieceItem(item));
            }
        }

        private void RefreshEliminatedPieces(ObservableCollection<PieceItem> collection, PieceColor color)
        {
            var itemsToAdd = this.gameController.EliminatedPieces.Where(p => p.Color == color && !collection.Any(i => i.Piece == p));
            foreach (var item in itemsToAdd)
            {
                collection.Add(new PieceItem(item));
            }
        }

        #endregion
    }
}

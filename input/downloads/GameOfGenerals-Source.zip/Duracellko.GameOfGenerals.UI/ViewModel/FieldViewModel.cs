﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public abstract class FieldViewModel : ViewModelBase
    {
        #region Constructor

        public FieldViewModel(BoardViewModel parent)
        {
            if (parent == null)
            {
                throw new ArgumentNullException("parent");
            }

            this.Parent = parent;
        }

        public FieldViewModel(BoardViewModel parent, int x, int y)
            : this(parent)
        {
            this.x = x;
            this.y = y;
        }

        #endregion

        #region Properties

        public BoardViewModel Parent { get; private set; }

        private int x;

        public int X
        {
            get { return x; }
        }

        private int y;

        public int Y
        {
            get { return y; }
        }

        #endregion

        #region Public methods

        public void Move(int x, int y)
        {
            this.Set(() => this.X, ref this.x, x);
            this.Set(() => this.Y, ref this.y, y);
        }

        #endregion
    }
}

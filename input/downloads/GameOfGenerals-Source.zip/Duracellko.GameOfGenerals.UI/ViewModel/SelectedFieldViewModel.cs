﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class SelectedFieldViewModel : FieldViewModel
    {
        #region Constructor

        public SelectedFieldViewModel(BoardViewModel parent)
            : base(parent)
        {
            this.Initialize();
        }

        public SelectedFieldViewModel(BoardViewModel parent, int x, int y)
            : base(parent, x, y)
        {
            this.Initialize();
        }

        private void Initialize()
        {
            this.clickCommand = new RelayCommand(this.OnClickCommand);
        }

        #endregion

        #region Commands

        private RelayCommand clickCommand;

        public ICommand ClickCommand
        {
            get { return this.clickCommand; }
        }

        private void OnClickCommand()
        {
            this.Parent.UnselectPiece(this);
        }

        #endregion

    }
}

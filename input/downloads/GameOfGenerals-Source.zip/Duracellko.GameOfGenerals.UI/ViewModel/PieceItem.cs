﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Duracellko.GameOfGenerals.Domain;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class PieceItem
    {
        public PieceItem(Piece piece)
        {
            if (piece == null)
            {
                throw new ArgumentNullException("piece");
            }

            this.Piece = piece;
        }

        public Piece Piece { get; private set; }

        public PieceColor Color
        {
            get { return this.Piece.Color; }
        }

        public PieceType Type
        {
            get { return this.Piece.Type; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Duracellko.GameOfGenerals.Communication;
using Duracellko.GameOfGenerals.UI.Messaging;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;

namespace Duracellko.GameOfGenerals.UI.ViewModel
{
    public class GameManagerViewModel : ViewModelBase
    {
        #region Fields

        private readonly ObservableCollection<GameItem> availableGames = new ObservableCollection<GameItem>();
        private readonly IGameConnectionManager gameConnectionManager;

        #endregion

        #region Constructor

        public GameManagerViewModel(IGameConnectionManager gameConnectionManager)
        {
            if (gameConnectionManager == null)
            {
                throw new ArgumentNullException("gameConnectionManager");
            }

            this.connectCommand = new RelayCommand(this.OnConnectCommand, () => this.SelectedGame != null);
            this.acceptRequestCommand = new RelayCommand(this.OnAcceptRequestCommand, () => this.IsGameRequestVisible);
            this.rejectRequestCommand = new RelayCommand(this.OnRejectRequestCommand, () => this.IsGameRequestVisible);

            this.gameConnectionManager = gameConnectionManager;
            this.gameConnectionManager.GameConnectionFound += this.GameConnectionManagerOnGameConnectionFound;
            this.gameConnectionManager.GameRequested += this.GameConnectionManagerOnGameRequested;
            this.gameConnectionManager.GameRequestAccepted += this.GameConnectionManagerOnGameRequestAccepted;
            this.gameConnectionManager.GameRequestRejected += this.GameConnectionManagerOnGameRequestRejected;
            this.gameConnectionManager.PublishMyName(null);
        }

        #endregion

        #region Properties

        public IReadOnlyList<GameItem> AvailableGames
        {
            get { return this.availableGames; }
        }

        private GameItem selectedGame;

        public GameItem SelectedGame
        {
            get { return this.selectedGame; }
            set
            {
                if (value != this.selectedGame)
                {
                    this.selectedGame = value;
                    this.RaisePropertyChanged(() => this.SelectedGame);
                    this.connectCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private bool isConnecting;

        public bool IsConnecting
        {
            get { return this.isConnecting; }
            private set { this.Set(() => this.IsConnecting, ref this.isConnecting, value); }
        }

        public bool isGameRequestVisible;

        public bool IsGameRequestVisible
        {
            get { return this.isGameRequestVisible; }
            private set
            {
                if (value != this.isGameRequestVisible)
                {
                    this.isGameRequestVisible = value;
                    this.RaisePropertyChanged(() => this.IsGameRequestVisible);
                    this.acceptRequestCommand.RaiseCanExecuteChanged();
                    this.rejectRequestCommand.RaiseCanExecuteChanged();
                }
            }
        }

        private string gameRequestText;

        public string GameRequestText
        {
            get { return this.gameRequestText; }
            private set { this.Set(() => this.GameRequestText, ref this.gameRequestText, value); }
        }

        #endregion

        #region Commands

        private readonly RelayCommand connectCommand;

        public ICommand ConnectCommand
        {
            get { return this.connectCommand; }
        }

        private readonly RelayCommand acceptRequestCommand;

        public ICommand AcceptRequestCommand
        {
            get { return this.acceptRequestCommand; }
        }

        private readonly RelayCommand rejectRequestCommand;

        public ICommand RejectRequestCommand
        {
            get { return this.rejectRequestCommand; }
        }

        #endregion

        #region Private methods

        private void OnConnectCommand()
        {
            if (this.SelectedGame != null)
            {
                this.gameConnectionManager.Connect(this.SelectedGame.Address);
                this.IsConnecting = true;
            }
        }

        private void OnAcceptRequestCommand()
        {
            this.gameConnectionManager.Accept();
            this.IsGameRequestVisible = false;
            Messenger.Default.Send(new OpenWindowMessage(ViewNames.Game, this.gameConnectionManager.GameController));
        }

        private void OnRejectRequestCommand()
        {
            this.gameConnectionManager.Reject();
            this.IsGameRequestVisible = false;
        }

        private void GameConnectionManagerOnGameConnectionFound(object sender, GameConnectionEventArgs e)
        {
            if (!this.availableGames.Any(i => string.Equals(i.Address, e.Address, StringComparison.OrdinalIgnoreCase)))
            {
                var gameItem = new GameItem(e.Address, e.Name);
                this.availableGames.Add(gameItem);
            }
        }

        private void GameConnectionManagerOnGameRequested(object sender, GameConnectionEventArgs e)
        {
            this.GameRequestText = e.Name;
            this.IsGameRequestVisible = true;
        }

        private void GameConnectionManagerOnGameRequestAccepted(object sender, GameConnectionEventArgs e)
        {
            Messenger.Default.Send(new OpenWindowMessage(ViewNames.Game, this.gameConnectionManager.GameController));
            this.IsConnecting = false;
        }

        private void GameConnectionManagerOnGameRequestRejected(object sender, EventArgs e)
        {
            this.IsConnecting = false;
        }

        #endregion
    }
}

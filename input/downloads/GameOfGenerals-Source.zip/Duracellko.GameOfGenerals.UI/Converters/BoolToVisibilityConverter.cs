﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Duracellko.GameOfGenerals.UI.Converters
{
    public class BoolToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (targetType == null)
            {
                throw new ArgumentNullException("targetType");
            }

            if (targetType != typeof(Visibility))
            {
                throw new ArgumentException(Properties.Resources.Error_TargetTypeNotSupported, "targetType");
            }

            if (value == null)
            {
                return null;
            }

            if (value is bool)
            {
                return ((bool)value) ? Visibility.Visible : Visibility.Collapsed;
            }
            else
            {
                throw new ArgumentException(Properties.Resources.Error_SourceTypeNotSupported, "value");
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (targetType == null)
            {
                throw new ArgumentNullException("targetType");
            }

            if (targetType != typeof(bool))
            {
                throw new ArgumentException(Properties.Resources.Error_TargetTypeNotSupported, "targetType");
            }

            if (value == null)
            {
                return null;
            }

            if (value is Visibility)
            {
                return ((Visibility)value) == Visibility.Visible;
            }
            else
            {
                throw new ArgumentException(Properties.Resources.Error_SourceTypeNotSupported, "value");
            }
        }
    }
}

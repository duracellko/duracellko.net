﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Duracellko.GameOfGenerals.UI.ViewModel;

namespace Duracellko.GameOfGenerals.UI.Converters
{
    public class BoardFieldTemplateSelector : DataTemplateSelector
    {
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (item == null)
            {
                return null;
            }

            var element = container as FrameworkElement;
            if (element == null)
            {
                return null;
            }

            string resourceKey = null;
            if (item is SetupFieldViewModel)
            {
                resourceKey = "GameBoard-SetupFieldDataTemplate";
            }
            else if (item is PieceDragFieldViewModel)
            {
                resourceKey = "GameBoard-PieceDragFieldDataTemplate";
            }
            else if (item is PieceFieldViewModel)
            {
                resourceKey = ((PieceFieldViewModel)item).Hidden ? "GameBoard-HiddenPieceFieldDataTemplate" : "GameBoard-PieceFieldDataTemplate";
            }
            else if (item is SelectFieldViewModel)
            {
                resourceKey = "GameBoard-SelectFieldDataTemplate";
            }
            else if (item is SelectDirectionFieldViewModel)
            {
                resourceKey = "GameBoard-SelectDirectionFieldDataTemplate";
            }
            else if (item is SelectedFieldViewModel)
            {
                resourceKey = "GameBoard-SelectedFieldDataTemplate";
            }
            else if (item is MoveInfoFieldViewModel)
            {
                resourceKey = "GameBoard-MoveInfoFieldDataTemplate";
            }

            return resourceKey != null ? (DataTemplate)element.FindResource(resourceKey) : null;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Duracellko.GameOfGenerals.UI.ViewModel;

namespace Duracellko.GameOfGenerals.UI.Converters
{
    public class PieceTemplateSelector : DataTemplateSelector
    {
        public bool Hidden { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            var pieceItem = item as PieceItem;
            var element = container as FrameworkElement;
            if (pieceItem != null && element != null)
            {
                object pieceType = this.Hidden ? (object)"Hidden" : pieceItem.Type;
                var resourceKey = string.Format(CultureInfo.InvariantCulture, "GamePiece${0}${1}", pieceType, pieceItem.Color);
                return (DataTemplate)element.FindResource(resourceKey);
            }

            return null;
        }
    }
}

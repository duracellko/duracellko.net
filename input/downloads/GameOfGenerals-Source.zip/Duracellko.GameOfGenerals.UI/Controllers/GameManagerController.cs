﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Duracellko.GameOfGenerals.Communication;
using Duracellko.GameOfGenerals.Communication.Client;
using Duracellko.GameOfGenerals.Communication.Connections;
using Duracellko.GameOfGenerals.Communication.Service;
using Duracellko.GameOfGenerals.UI.ViewModel;
using Duracellko.GameOfGenerals.UI.Views;
using GalaSoft.MvvmLight;

namespace Duracellko.GameOfGenerals.UI.Controllers
{
    public class GameManagerController : IUiController
    {
        public ViewModelBase CreateViewModel(object parameter)
        {
            var connectionManager = (IGameConnectionManager)parameter;
            return new GameManagerViewModel(connectionManager);
        }

        public FrameworkElement CreateView()
        {
            return new GameManagerView();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Duracellko.GameOfGenerals.Domain;
using Duracellko.GameOfGenerals.UI.ViewModel;
using Duracellko.GameOfGenerals.UI.Views;
using GalaSoft.MvvmLight;

namespace Duracellko.GameOfGenerals.UI.Controllers
{
    public class GameUiController : IUiController
    {
        public ViewModelBase CreateViewModel(object parameter)
        {
            var gameController = (IGameController)parameter;
            return new GameViewModel(gameController);
        }

        public FrameworkElement CreateView()
        {
            return new GameView();
        }
    }
}

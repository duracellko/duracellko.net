﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Duracellko.GameOfGenerals.UI
{
    public interface IShell
    {
        void ClosePage();

        void OpenPage(FrameworkElement element);
    }
}

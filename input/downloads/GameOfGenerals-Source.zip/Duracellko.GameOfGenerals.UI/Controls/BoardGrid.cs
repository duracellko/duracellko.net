﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Duracellko.GameOfGenerals.UI.Controls
{
    public class BoardGrid : Grid
    {
        #region Dependency properties

        public static readonly DependencyProperty ColumnsCountProperty = DependencyProperty.Register(
            "ColumnsCount",
            typeof(int),
            typeof(BoardGrid),
            new PropertyMetadata(0, OnColumnsCountChanged),
            ColumnsRowsCountValidate);

        public static readonly DependencyProperty RowsCountProperty = DependencyProperty.Register(
            "RowsCount",
            typeof(int),
            typeof(BoardGrid),
            new PropertyMetadata(0, OnRowsCountChanged),
            ColumnsRowsCountValidate);

        public static readonly DependencyProperty CellTemplateProperty = DependencyProperty.Register(
            "CellTemplate",
            typeof(DataTemplate),
            typeof(BoardGrid),
            new PropertyMetadata(OnCellTemplateChanged));

        #endregion

        #region Properties

        public int ColumnsCount
        {
            get { return (int)this.GetValue(ColumnsCountProperty); }
            set { this.SetValue(ColumnsCountProperty, value); }
        }

        public int RowsCount
        {
            get { return (int)this.GetValue(RowsCountProperty); }
            set { this.SetValue(RowsCountProperty, value); }
        }

        public DataTemplate CellTemplate
        {
            get { return (DataTemplate)this.GetValue(CellTemplateProperty); }
            set { this.SetValue(CellTemplateProperty, value); }
        }

        #endregion

        #region Private methods

        private static void OnColumnsCountChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((BoardGrid)d).OnColumnsCountChanged(e);
        }

        private void OnColumnsCountChanged(DependencyPropertyChangedEventArgs e)
        {
            var newColumnsCount = (int)e.NewValue;
            if (this.CellTemplate != null)
            {
                this.Children.Clear();
            }

            if (newColumnsCount == 0)
            {
                this.ColumnDefinitions.Clear();
            }

            while (newColumnsCount > this.ColumnDefinitions.Count)
            {
                this.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1.0, GridUnitType.Star) });
            }

            while (newColumnsCount < this.ColumnDefinitions.Count)
            {
                this.ColumnDefinitions.RemoveAt(this.ColumnDefinitions.Count - 1);
            }

            this.RecreateChildren();
        }

        private static void OnRowsCountChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((BoardGrid)d).OnRowsCountChanged(e);
        }

        private void OnRowsCountChanged(DependencyPropertyChangedEventArgs e)
        {
            var newRowsCount = (int)e.NewValue;
            if (this.CellTemplate != null)
            {
                this.Children.Clear();
            }

            if (newRowsCount == 0)
            {
                this.RowDefinitions.Clear();
            }

            while (newRowsCount > this.RowDefinitions.Count)
            {
                this.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1.0, GridUnitType.Star) });
            }

            while (newRowsCount < this.RowDefinitions.Count)
            {
                this.RowDefinitions.RemoveAt(this.RowDefinitions.Count - 1);
            }

            this.RecreateChildren();
        }

        private static void OnCellTemplateChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((BoardGrid)d).OnCellTemplateChanged(e);
        }

        private void OnCellTemplateChanged(DependencyPropertyChangedEventArgs e)
        {
            if (this.CellTemplate != null)
            {
                this.Children.Clear();
            }

            this.RecreateChildren();
        }

        private static bool ColumnsRowsCountValidate(object value)
        {
            return Convert.ToInt32(value) >= 0;
        }

        private void RecreateChildren()
        {
            if (this.CellTemplate != null)
            {
                for (int i = 0; i < this.ColumnDefinitions.Count; i++)
                {
                    for (int j = 0; j < this.RowDefinitions.Count; j++)
                    {
                        var cellContent = this.CellTemplate.LoadContent();
                        cellContent.SetValue(Grid.ColumnProperty, i);
                        cellContent.SetValue(Grid.RowProperty, j);
                        this.Children.Add((UIElement)cellContent);
                    }
                }
            }
        }

        #endregion
    }
}

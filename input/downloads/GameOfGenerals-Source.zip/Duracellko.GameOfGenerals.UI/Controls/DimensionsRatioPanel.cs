﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Duracellko.GameOfGenerals.UI.Controls
{
    public class DimensionsRatioPanel : ContentControl
    {
        #region Dependency properties

        public static readonly DependencyProperty HeightRatioProperty = DependencyProperty.Register(
            "HeightRatio",
            typeof(double),
            typeof(DimensionsRatioPanel),
            new FrameworkPropertyMetadata(1.0, FrameworkPropertyMetadataOptions.AffectsArrange),
            RatioValidate);

        public static readonly DependencyProperty WidthRatioProperty = DependencyProperty.Register(
            "WidthRatio",
            typeof(double),
            typeof(DimensionsRatioPanel),
            new FrameworkPropertyMetadata(1.0, FrameworkPropertyMetadataOptions.AffectsArrange),
            RatioValidate);

        #endregion

        #region Properties

        public double HeightRatio
        {
            get { return (double)this.GetValue(HeightRatioProperty); }
            set { this.SetValue(HeightRatioProperty, value); }
        }

        public double WidthRatio
        {
            get { return (double)this.GetValue(WidthRatioProperty); }
            set { this.SetValue(WidthRatioProperty, value); }
        }

        #endregion

        #region Protected methods

        protected override Size ArrangeOverride(Size arrangeSize)
        {
            double heightRatio = this.HeightRatio;
            double widthRatio = this.WidthRatio;

            var newSize = new Size(arrangeSize.Width, arrangeSize.Width * heightRatio / widthRatio);
            if (newSize.Height > arrangeSize.Height)
            {
                newSize = new Size(arrangeSize.Height * widthRatio / heightRatio, arrangeSize.Height);
            }

            return base.ArrangeOverride(newSize);
        }

        #endregion

        #region Private methods

        private static bool RatioValidate(object value)
        {
            return Convert.ToDouble(value) > 0.0;
        }

        #endregion
    }
}

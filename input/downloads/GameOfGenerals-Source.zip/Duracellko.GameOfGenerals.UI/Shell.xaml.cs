﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace Duracellko.GameOfGenerals.UI
{
    /// <summary>
    /// Interaction logic for Shell.xaml
    /// </summary>
    public partial class Shell : UserControl, IShell
    {
        public Shell()
        {
            InitializeComponent();
        }

        #region IShell

        public void ClosePage()
        {
            this.ShellContent.Children.Clear();
        }

        public void OpenPage(FrameworkElement element)
        {
            this.ShellContent.Children.Add(element);
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Duracellko.GameOfGenerals.UI
{
    public static class ViewNames
    {
        public const string GameManager = "GameManager";

        public const string Game = "Game";
    }
}

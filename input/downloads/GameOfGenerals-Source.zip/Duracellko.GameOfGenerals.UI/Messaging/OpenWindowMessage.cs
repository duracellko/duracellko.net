﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GalaSoft.MvvmLight.Messaging;

namespace Duracellko.GameOfGenerals.UI.Messaging
{
    public class OpenWindowMessage : GenericMessage<string>
    {
        public OpenWindowMessage(string name)
            : base(name)
        {
        }

        public OpenWindowMessage(string name, object parameter)
            : base(name)
        {
            this.Parameter = parameter;
        }

        public object Parameter { get; protected set; }
    }
}

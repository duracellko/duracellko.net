﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Duracellko.GameOfGenerals.UI.Controllers;
using Duracellko.GameOfGenerals.UI.Messaging;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Messaging;

namespace Duracellko.GameOfGenerals.UI
{
    public class WindowManager : IDisposable
    {
        #region Fields

        private readonly Dictionary<string, IUiController> controllers = new Dictionary<string, IUiController>();

        private ViewModelBase currentViewModel;
        private FrameworkElement currentView;

        #endregion

        #region Constructor

        public WindowManager(IShell shell)
        {
            if (shell == null)
            {
                throw new ArgumentNullException("shell");
            }

            this.Shell = shell;
            Messenger.Default.Register<OpenWindowMessage>(this, this.OnOpenWindowMessage);
        }

        #endregion

        #region Properties

        public IShell Shell { get; private set; }

        #endregion

        #region Public methods

        public void OpenWindow(string name)
        {
            this.OpenWindow(name, null);
        }

        public void OpenWindow(string name, object parameter)
        {
            this.OpenWindow(this.controllers[name], parameter);
        }

        public void OpenWindow(IUiController controller, object parameter)
        {
            this.CloseWindow();

            this.currentViewModel = controller.CreateViewModel(parameter);
            this.currentView = controller.CreateView();
            this.currentView.DataContext = this.currentViewModel;

            this.Shell.OpenPage(this.currentView);
        }

        public void CloseWindow()
        {
            if (this.currentView != null)
            {
                this.Shell.ClosePage();

                if (this.currentView.DataContext == this.currentViewModel)
                {
                    this.currentView.DataContext = null;
                }

                this.currentView = null;
            }

            if (this.currentViewModel != null)
            {
                var cleanup = this.currentViewModel as ICleanup;
                if (cleanup != null)
                {
                    cleanup.Cleanup();
                }

                this.currentViewModel = null;
            }
        }

        public void RegisterController(string name, IUiController controller)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name");
            }

            if (controller == null)
            {
                throw new ArgumentNullException("controller");
            }

            this.controllers.Add(name, controller);
        }

        public bool UnregisterController(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name");
            }

            return this.controllers.Remove(name);
        }

        #endregion

        #region Private methods

        private void OnOpenWindowMessage(OpenWindowMessage message)
        {
            this.OpenWindow(message.Content, message.Parameter);
        }

        #endregion

        #region IDisposable

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                Messenger.Default.Unregister(this);
            }
        }

        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}

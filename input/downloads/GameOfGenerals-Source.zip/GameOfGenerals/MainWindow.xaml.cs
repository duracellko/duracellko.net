﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Duracellko.GameOfGenerals.Communication;
using Duracellko.GameOfGenerals.Communication.Client;
using Duracellko.GameOfGenerals.Communication.Connections;
using Duracellko.GameOfGenerals.Communication.Service;
using Duracellko.GameOfGenerals.UI;
using Duracellko.GameOfGenerals.UI.Controllers;

namespace Duracellko.GameOfGenerals
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable", Justification = "Members are disposed when the window is closed.")]
    public partial class MainWindow : Window
    {
        private WindowManager windowManager;
        private GameConnectionManager connectionManager;

        public MainWindow()
        {
            this.InitializeComponent();

            this.Loaded += this.MainWindowOnLoaded;
        }

        private void MainWindowOnLoaded(object sender, RoutedEventArgs e)
        {
            this.windowManager = new WindowManager(this.Shell);
            this.RegisterControllers();

            this.CreateGameConnectionManager();

            this.windowManager.OpenWindow(ViewNames.GameManager, this.connectionManager);
        }

        protected override void OnClosed(EventArgs e)
        {
            if (this.windowManager != null)
            {
                this.windowManager.Dispose();
                this.windowManager = null;
            }

            if (this.connectionManager != null)
            {
                this.connectionManager.Dispose();
                this.connectionManager = null;
            }

            base.OnClosed(e);
        }

        private void CreateGameConnectionManager()
        {
            var taskScheduler = TaskScheduler.FromCurrentSynchronizationContext();

            var gameControllerFactory = new GameControllerFactory();
            var gameServiceHostFactory = new GameServiceHostFactory() { TaskScheduler = taskScheduler };
            var gameClientFactory = new GameClientFactory() { TaskScheduler = taskScheduler };
            var gameConnectionPublisherFactory = new UdpGameConnectionPublisherFactory();
            this.connectionManager = new GameConnectionManager(gameControllerFactory, gameServiceHostFactory, gameClientFactory, gameConnectionPublisherFactory);
            this.connectionManager.TaskScheduler = taskScheduler;
        }

        private void RegisterControllers()
        {
            this.windowManager.RegisterController(ViewNames.Game, new GameUiController());
            this.windowManager.RegisterController(ViewNames.GameManager, new GameManagerController());
        }
    }
}
